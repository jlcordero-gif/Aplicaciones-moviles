package com.example.simulacro11

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.simulacro11.ui.Apuesta.ViewApuesta
import com.example.simulacro11.ui.Eleccion.ViewEleccion
import com.example.simulacro11.ui.Resultado.ViewResultado

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            val gameViewModel: GameViewModel = viewModel()

            NavHost(navController = navController, startDestination = "eleccion") {

                composable("eleccion") {
                    ViewEleccion(
                        onNumeroSeleccionado = { num ->
                            gameViewModel.elegirNumero(num)
                            navController.navigate("apuesta")
                        }
                    )
                }

                composable("apuesta") {
                    ViewApuesta(
                        saldo = gameViewModel.saldo,
                        numeroElegido = gameViewModel.numeroElegido ?: 0,
                        onApostar = { cantidad ->
                            gameViewModel.realizarApuesta(cantidad)
                            gameViewModel.sortear()
                            navController.navigate("resultado")
                        }
                    )
                }

                composable("resultado") {
                    ViewResultado(
                        numeroElegido = gameViewModel.numeroElegido ?: 0,
                        numeroGanador = gameViewModel.numeroGanador,
                        saldo = gameViewModel.saldo,
                        onJugarDeNuevo = {
                            gameViewModel.reiniciarJuego()
                            navController.navigate("eleccion") {
                                popUpTo("eleccion") { inclusive = true }
                            }
                        },
                        onSalir = {
                            gameViewModel.reiniciarTotal()
                            navController.navigate("eleccion") {
                                popUpTo("eleccion") { inclusive = true }
                            }
                        }
                    )
                }

            }
        }
    }
}
