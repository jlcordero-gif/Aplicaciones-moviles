package com.example.simulacro11.ui.Resultado

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ViewResultado(
    numeroElegido: Int,
    numeroGanador: Int,
    saldo: Int,
    onJugarDeNuevo: () -> Unit,
    onSalir: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Text("Número ganador:", fontSize = 24.sp)
        Text(numeroGanador.toString(), fontSize = 60.sp, fontWeight = FontWeight.Bold)

        Spacer(Modifier.height(20.dp))

        if (numeroElegido == numeroGanador) {
            Text("Has ganado ",fontSize = 30.sp)
        } else {
            Text("Has perdido",fontSize = 30.sp)
        }

        Spacer(Modifier.height(20.dp))
        Text("Saldo actual: $saldo créditos", fontSize = 24.sp)

        Spacer(Modifier.height(40.dp))

        Button(onClick = onJugarDeNuevo, modifier = Modifier.fillMaxWidth()) {
            Text("Jugar de nuevo")
        }
        Spacer(Modifier.height(10.dp))
        Button(onClick = onSalir, modifier = Modifier.fillMaxWidth()) {
            Text("Salir")
        }
    }
}
