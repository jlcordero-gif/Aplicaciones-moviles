package com.example.simulacro11

import androidx.lifecycle.ViewModel
import kotlin.random.Random

class GameViewModel : ViewModel() {

    var saldo: Int = 10
    var numeroElegido: Int? = null
    var apuesta: Int = 0
    var numeroGanador: Int = 0

    fun elegirNumero(n: Int) {
        numeroElegido = n
    }

    fun realizarApuesta(cantidad: Int) {
        apuesta = cantidad
    }

    fun sortear() {
        numeroGanador = Random.nextInt(1, 10)
        if (numeroGanador == numeroElegido) {
            saldo += apuesta * 2
        } else {
            saldo -= apuesta
        }
    }

    fun reiniciarJuego() {
        numeroElegido = null
        apuesta = 0
        numeroGanador = 0
    }

    fun reiniciarTotal() {
        saldo = 10
        reiniciarJuego()
    }
}

