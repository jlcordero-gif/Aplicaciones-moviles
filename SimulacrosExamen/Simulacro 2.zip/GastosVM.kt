package com.example.simulacro2

import androidx.lifecycle.ViewModel

class GastosVM : ViewModel() {

    var total: Double = 0.0
    var numPersonas: Int = 0
    var nombres: MutableList<String> = mutableListOf()

    fun guardarDatosIniciales(totalIngresado: Double, personasIngresadas: Int) {
        total = totalIngresado
        numPersonas = personasIngresadas
        nombres = MutableList(numPersonas) { "" }
    }


}
