package com.example.simulacro2.ui.numeros

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun NumerosScreen(
    onContinuar: (Double, Int) -> Unit
) {
    var total by remember { mutableStateOf("") }
    var personas by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Gastos:", fontSize = 28.sp)

        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            value = total,
            onValueChange = { if (it.all { c -> c.isDigit() || c == '.' }) total = it },
            label = { Text("Total a dividir") }
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = personas,
            onValueChange = { if (it.all { c -> c.isDigit() }) personas = it },
            label = { Text("Número de personas") }
        )

        Spacer(Modifier.height(20.dp))

        Button(onClick = {
            val t = total.toDoubleOrNull() ?: 0.0
            val p = personas.toIntOrNull() ?: 0
            if (t > 0 && p > 0) onContinuar(t, p)
        }) {
            Text("Continuar")
        }
    }
}